
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import BottomButton from '../../components/bottom-button/BottomButton'
import { me, navigateForOnboarding } from '../../api/authApi'
import { messageOf } from '../../api/http'
import './SignupWaiting.css'

export default function SignupWaiting() {
  const navigate=useNavigate()
  const [error,setError]=useState('')

  const check=async()=>{
    try{
      const user=await me()
      if(user.onboardingState==='WAITING_APPROVAL')
        setError('아직 승인 대기 중입니다.')
      else
        navigateForOnboarding(navigate,user)
    }catch(e){
      setError(messageOf(e))
    }
  }

  return (
    <main className="SignupWaitingPage">
      <h1 className="SignupWaitingPage__title">
        요청을 승인하고 있어요
      </h1>
      {error && <p role="status">{error}</p>}
      <BottomButton content="승인 상태 확인" onClick={check}/>
    </main>
  )
}
